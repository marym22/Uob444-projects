import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ionic-inputs',
  templateUrl: './ionic-inputs.page.html',
  styleUrls: ['./ionic-inputs.page.scss'],
})
export class IonicInputsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
