import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ionic-icons',
  templateUrl: './ionic-icons.page.html',
  styleUrls: ['./ionic-icons.page.scss'],
})
export class IonicIconsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
