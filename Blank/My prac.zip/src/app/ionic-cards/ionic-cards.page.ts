import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ionic-cards',
  templateUrl: './ionic-cards.page.html',
  styleUrls: ['./ionic-cards.page.scss'],
})
export class IonicCardsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
