import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ionic-label',
  templateUrl: './ionic-label.page.html',
  styleUrls: ['./ionic-label.page.scss'],
})
export class IonicLabelPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
