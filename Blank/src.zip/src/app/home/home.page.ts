import { Component } from '@angular/core';
import { DataService } from '../data.service';
import { LoadingController } from '@ionic/angular';


@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  public showH = false;

  constructor( public DataSrv: DataService, public loadingCtrl: LoadingController ) {}

  async delete( ) 
  {
    const loader = await this.loadingCtrl.create({
      message: "Please wait... Item is getting deleted",
      duration: 2000
    });
    await loader.present();
    this.DataSrv.List.splice(0,1);
  }

}
