import { Component, OnInit } from '@angular/core';
import { DataService, Product } from '../data.service';
import { AlertController } from '@ionic/angular';


@Component({
  selector: 'app-edit',
  templateUrl: './edit.page.html',
  styleUrls: ['./edit.page.scss'],
})
export class EditPage implements OnInit {

  ind = 0;
  newList : Product = {} as Product;

  section = "";
  category ="";
  name = "";
  price = 0;


  async save(){
    this.section = this.DataSrv.Sections[this.ind].Section;
    this.newList.Section = this.section;
    this.newList.Category = this.category;
    this.newList.Name = this.name;
    this.newList.Price_history[this.ind].price = this.price;
    this.DataSrv.List.push();

    let alert = this.alertCtrl.create({
      header:'Insert Member',
      message: `none`,
      buttons: 
      ['OK']
    });
    // show alert
    (await alert).present();
  }

  constructor( public DataSrv: DataService, public alertCtrl: AlertController ) { }

  ngOnInit() {
  }

}
