import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)
  },
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    path: 'ionic-inputs',
    loadChildren: () => import('./ionic-inputs/ionic-inputs.module').then( m => m.IonicInputsPageModule)
  },
  {
    path: 'ionic-label',
    loadChildren: () => import('./ionic-label/ionic-label.module').then( m => m.IonicLabelPageModule)
  },
  {
    path: 'ionic-button',
    loadChildren: () => import('./ionic-button/ionic-button.module').then( m => m.IonicButtonPageModule)
  },
  {
    path: 'ionic-icons',
    loadChildren: () => import('./ionic-icons/ionic-icons.module').then( m => m.IonicIconsPageModule)
  },
  {
    path: 'ionic-alert-ex',
    loadChildren: () => import('./ionic-alert-ex/ionic-alert-ex.module').then( m => m.IonicAlertExPageModule)
  },
  {
    path: 'example1',
    loadChildren: () => import('./example1/example1.module').then( m => m.Example1PageModule)
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
