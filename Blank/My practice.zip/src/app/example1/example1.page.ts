import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-example1',
  templateUrl: './example1.page.html',
  styleUrls: ['./example1.page.scss'],
})
export class Example1Page implements OnInit {

  public count= 0;

  constructor( ) 
  { }
  
  TapMe( ) 
  {
    this.count++;
  }
  
  Reset( ) 
  {
    this.count = 0;
  }

  ngOnInit( ) 
  { }

}
