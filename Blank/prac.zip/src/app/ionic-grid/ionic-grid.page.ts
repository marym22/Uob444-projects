import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ionic-grid',
  templateUrl: './ionic-grid.page.html',
  styleUrls: ['./ionic-grid.page.scss'],
})
export class IonicGridPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
