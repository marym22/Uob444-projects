import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ionic-toggle',
  templateUrl: './ionic-toggle.page.html',
  styleUrls: ['./ionic-toggle.page.scss'],
})
export class IonicTogglePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
