import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ex4',
  templateUrl: './ex4.page.html',
  styleUrls: ['./ex4.page.scss'],
})
export class Ex4Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
