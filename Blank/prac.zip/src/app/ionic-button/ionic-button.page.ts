import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ionic-button',
  templateUrl: './ionic-button.page.html',
  styleUrls: ['./ionic-button.page.scss'],
})
export class IonicButtonPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
