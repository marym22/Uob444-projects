import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ionic-radio',
  templateUrl: './ionic-radio.page.html',
  styleUrls: ['./ionic-radio.page.scss'],
})
export class IonicRadioPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
