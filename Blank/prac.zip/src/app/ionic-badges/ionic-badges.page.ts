import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ionic-badges',
  templateUrl: './ionic-badges.page.html',
  styleUrls: ['./ionic-badges.page.scss'],
})
export class IonicBadgesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
