import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ionic-checkbox',
  templateUrl: './ionic-checkbox.page.html',
  styleUrls: ['./ionic-checkbox.page.scss'],
})
export class IonicCheckboxPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
