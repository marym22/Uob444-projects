import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ionic-fabs',
  templateUrl: './ionic-fabs.page.html',
  styleUrls: ['./ionic-fabs.page.scss'],
})
export class IonicFabsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
