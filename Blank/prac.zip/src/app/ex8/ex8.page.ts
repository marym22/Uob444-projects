import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ex8',
  templateUrl: './ex8.page.html',
  styleUrls: ['./ex8.page.scss'],
})
export class Ex8Page implements OnInit {

  public Courses = 
  [
    { Code: "ITCS113", Grade: "", Points: 0, Credits: 3 },
    { Code: "MGT131" , Grade: "", Points: 0, Credits: 3 },
    { Code: "ENGL219", Grade: "", Points: 0, Credits: 3 }
  ];
   
  public Grades = 
  [ 
    { grade: "A" , points: 4.0 },
    { grade: "A-" , points: 3.67 },
    { grade: "B+" , points: 3.33 },
    { grade: "B" , points: 3.0 },
    { grade: "F" , points: 0.0 }
  ];
      
   CalGPA()
   {
      let sum = 0;
      let sumCredit = 0;
     
     for (let c of this.Courses)
      {
        sum += c.Points*c.Credits;
        sumCredit += c.Credits;
      }
      alert("GPA= " + sum/sumCredit);
     }   
    
  constructor() 
  {

  }

  ngOnInit() 
  {
  
  }

}
