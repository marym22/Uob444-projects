import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ionic-gestures',
  templateUrl: './ionic-gestures.page.html',
  styleUrls: ['./ionic-gestures.page.scss'],
})
export class IonicGesturesPage implements OnInit {

  constructor() { }

  onTap() {}
  onPress() {}
  onPan() {}
  onSwipe() {}
  onRotate() {}
  onPinch() {}
  onTouch() {}
  onMove() {}
  onEnd() {}
  onStart() {}
  onGesture() {}

  ngOnInit() {
  }

}
