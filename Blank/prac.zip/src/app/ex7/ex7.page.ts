import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ex7',
  templateUrl: './ex7.page.html',
  styleUrls: ['./ex7.page.scss'],
})
export class Ex7Page implements OnInit {

  public RateArray = 
  [
    { value: 1, icon: "star-outline" },
    { value: 2, icon: "star-outline" },
    { value: 3, icon: "star-outline" },
    { value: 4, icon: "star-outline" },
    { value: 5, icon: "star-outline" }
  ];

  public rating = 0;

  setRating(val: number){
     for (var i = 0; i < this.RateArray.length; i++) {
      if (i < val) {
     this.RateArray[i].icon = "star";
      }
      else {
     this.RateArray[i].icon = "star-outline";
     }
     } // end for 
      this.rating = val;
     }
    
  constructor() { }

  ngOnInit() {
  }

}
