import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ionic-searchbar',
  templateUrl: './ionic-searchbar.page.html',
  styleUrls: ['./ionic-searchbar.page.scss'],
})
export class IonicSearchbarPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
