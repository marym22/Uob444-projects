import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ionic-segment',
  templateUrl: './ionic-segment.page.html',
  styleUrls: ['./ionic-segment.page.scss'],
})
export class IonicSegmentPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
