import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ionic-select',
  templateUrl: './ionic-select.page.html',
  styleUrls: ['./ionic-select.page.scss'],
})
export class IonicSelectPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
