import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController, ModalController } from '@ionic/angular';
import { DataService, ListofTasks } from '../data.service';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.page.html',
  styleUrls: ['./edit.page.scss'],
})
export class EditPage implements OnInit {
newlist: ListofTasks = {Name:"", Tasks: []} as ListofTasks;

  constructor(public DataSrv:DataService, 
              public alertCtrl: AlertController,
              public router: Router,
              public modalCtrl: ModalController
              ) { }

  ngOnInit() {
  }

  // ionViewDidEnter(){
  //     alert("Entered Edit Page");
  // }

  // ionViewDidLeave(){
  //     alert("Left Edit Page");
  // }

  Insert(){
      this.DataSrv.List.push(this.newlist);
      this.ShowAlert();
      this.router.navigateByUrl("/home");
  }

  async ShowAlert(){
        let alert = await this.alertCtrl.create({
          header: "Insert",
          message:"Inserted Successfully",
          buttons: ["OK"]
        });

        alert.present();
  }

  Close(){
      this.modalCtrl.dismiss();
  }
}
