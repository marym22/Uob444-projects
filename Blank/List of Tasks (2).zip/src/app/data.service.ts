import { Injectable } from '@angular/core';

export interface ListofTasks {
  Name:   string;
  Tasks:  Task[];
}

export interface Task {
  Name:         string;
  Description:  string;
  DueDate:      Date;
  Status:       boolean;
}

@Injectable({
  providedIn: 'root'
})
export class DataService {
public index = -1;


  List: ListofTasks[] = 
        [ { Name: "List1", Tasks: [  {Name: "Task1", Description: "Wake up", DueDate: new Date(),Status: false}] },
          { Name: "List2", Tasks: [  {Name: "Task2", Description: "Go to S40", DueDate: new Date(),Status: false}] },
          { Name: "List3", Tasks: [  {Name: "Task3", Description: "Leave S40", DueDate: new Date(),Status: false}] }
        ];

  


  constructor() { }



}
