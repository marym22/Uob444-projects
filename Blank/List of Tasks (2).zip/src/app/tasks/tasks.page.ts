import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DataService, Task } from '../data.service';

@Component({
  selector: 'app-tasks',
  templateUrl: './tasks.page.html',
  styleUrls: ['./tasks.page.scss'],
})
export class TasksPage implements OnInit {
public indexStr = "-1";
public index = -1;
public newTask: Task = {} as Task;
public add: boolean = false;


  constructor(public DataSrv: DataService, public activatedRoute: ActivatedRoute) { 
  
  }

  ngOnInit() {
    this.indexStr = this.activatedRoute.snapshot.paramMap.get("i")??"";
    this.index = Number(this.indexStr);
    this.DataSrv.index = this.index;
  }

  SaveTask(){
    this.DataSrv.List[this.index].Tasks.push(this.newTask);
  }
}
