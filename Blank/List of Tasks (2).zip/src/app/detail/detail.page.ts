import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DataService, Task } from '../data.service';
import { TasksPageModule } from '../tasks/tasks.module';

@Component({
  selector: 'app-detail',
  templateUrl: './detail.page.html',
  styleUrls: ['./detail.page.scss'],
})
export class DetailPage implements OnInit {
public indexStr = "-1";
public index = -1;
public edit: boolean = false;
public editTask: Task = {} as Task;

  constructor(public DataSrv: DataService, public activatedRoute:ActivatedRoute) { 
    this.indexStr = this.activatedRoute.snapshot.paramMap.get("i")??"";
    this.index = Number(this.indexStr);
    this.editTask = {} as Task;
    this.editTask = {...this.DataSrv.List[DataSrv.index].Tasks[this.index]};
    //alert(this.DataSrv.index);
  }

  ngOnInit() {
  }

  
  //  ionViewDidEnter(){
  //     alert("Entered Edit Page");
  // }

  // ionViewDidLeave(){
  //     alert("Left Edit Page");
  // }

  Save(){
    this.DataSrv.List[this.DataSrv.index].Tasks[this.index] = this.editTask;
    alert("saved");
  }
}
