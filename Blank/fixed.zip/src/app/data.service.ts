import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  public List: Product[] = [
    { id: 1, name: 'Product 1', score: 1, icon: 'https://ionicframework.com/docs/demos/api/list/avatar-finn.png' },
    { id: 2, name: 'Product 2', score: 2, icon: 'https://ionicframework.com/docs/demos/api/list/avatar-finn.png' },
    { id: 3, name: 'Product 3', score: 3, icon: 'https://ionicframework.com/docs/demos/api/list/avatar-finn.png' },
    { id: 4, name: 'Product 4', score: 4, icon: 'https://ionicframework.com/docs/demos/api/list/avatar-finn.png' },
  ];  
  selectedProduct: any;

  getList() {
    return this.List;
  }
}



export class Product {
  id: number;
  name: string;
  score: number;
  icon: string;

  constructor(id: number, name: string, score: number, icon: string) {
    this.id = id;
    this.name = name;
    this.score = score;
    this.icon = icon;
  }
}
