import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { DataService } from '../data.service';

@Component({
  selector: 'app-item-view',
  templateUrl: './item-view.page.html',
  styleUrls: ['./item-view.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, FormsModule]
})
export class ItemViewPage implements OnInit {
  selectedProduct: any;
  productsList: any;

  constructor(private dataService: DataService) {
    this.productsList = this.dataService.getList();
  }
  

  updateProduct(index: number, updatedProduct: any) {
    this.productsList[index] = updatedProduct;
  }

  deleteProduct(index: number) {
    this.productsList.splice(index, 1);
  }


  ngOnInit() {
  }
}
