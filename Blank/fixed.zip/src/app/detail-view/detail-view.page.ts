import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule, NavController } from '@ionic/angular';
import { DataService, Product } from '../data.service';


@Component({
  selector: 'app-detail-view',
  templateUrl: './detail-view.page.html',
  styleUrls: ['./detail-view.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, FormsModule]
})
export class DetailViewPage implements OnInit {
  recordList = [
    { name: 'Car', score: 2 },
    { name: 'Train', score: 1 },
    { name: 'Plane', score: 3 },
  ];
  // Method to update the score value and button fills
  updateScore(record:any, score:any) {
    record.score = score;
    for (let i = 1; i <= score; i++) {
      record[`fill${i}`] = 'solid';
    }
    for (let i = score + 1; i <= 4; i++) {
      record[`fill${i}`] = 'outline';
    }
  }
  record: Product[]=[];
  onViewDetails(id:any) {
    const index = this.record[id];
    this.navCtrl.navigateForward('/detail-view:' + index);
      }

  constructor(public dataSrv:DataService, public navCtrl:NavController) {
   }

  ngOnInit() {
    this.record = {...this.dataSrv.List};
  }

}
