import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AlertController, IonicModule } from '@ionic/angular';
import { DataService, Product } from '../data.service';
import { ReactiveFormsModule } from '@angular/forms';
import {Validators, FormBuilder, FormGroup} from '@angular/forms';


@Component({
  selector: 'app-view',
  templateUrl: './view.page.html',
  styleUrls: ['./view.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, FormsModule, ReactiveFormsModule]
})

export class ViewPage implements OnInit {

  
onSubmit() {
console.log(this.form.value);
}
form: any;
insertProduct() {
  this.Datasrv.List.push(new Product(Math.random() * 1000, this.form.value.name, this.form.value.score, this.form.value.icon));
  this.form.reset();
  this.alertCtrl.create({
    header: 'Success',
    message: 'Product added',
    buttons: ['OK']
  }).then(alert => alert.present());

}
  constructor(public Datasrv:DataService,public alertCtrl:AlertController, private fb: FormBuilder) 
  {
    this.form = this.fb.group
    ({
      'id':['', Validators.required],
      'name':['', Validators.required],
      'score':['', Validators.required],
      'icon':['', Validators.required]    
    })
  }

  ngOnInit() {
  }

}
