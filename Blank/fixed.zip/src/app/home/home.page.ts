import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
})
export class HomePage implements OnInit {

    onViewItem() {
    this.navCtrl.navigateForward('/item-view');
  }

    onViewList() {
      this.navCtrl.navigateForward('/view');

    }
    onViewDetails() {
      this.navCtrl.navigateForward('/detail-view');
        }

  constructor(public navCtrl:NavController) {}
  ngOnInit() {
  }

}
