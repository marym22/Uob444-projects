import { Component, ViewChild } from '@angular/core';
import { AlertController, ModalController } from '@ionic/angular';
import { DataService } from '../data.service';
import { EditPage } from '../edit/edit.page';


@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})


export class HomePage {

  constructor(public modalCtrl: ModalController, public DataSrv: DataService,public alertCtrl: AlertController){}

  async Remove(i:number){

    let alert =await this.alertCtrl.create({
      header:"Delete",
      message: "Are you Sure?",
      buttons: [
        {
            text: "OK",
            handler: ()=>{this.DataSrv.List.splice(i,1);}
        },
        {
          text: "Cancel",
          handler: ()=>{}
      }
      ]
    });

    alert.present();
   }


   async openEdit(){
      let page = await this.modalCtrl.create({
        component: EditPage,
        backdropDismiss: false
      });

      page.present();
   }


}
